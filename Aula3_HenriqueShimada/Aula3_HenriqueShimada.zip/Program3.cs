﻿using System;
//Aula2_HenriqueShimada

namespace Exercicio3
{
    class Inicio
    {
        static void Main(string[] args)
        {
            Produto p = new Produto();
            Console.Write("Código: ");
            p.Codigo = Console.ReadLine();
            Console.Write("Descrição: ");
            p.Descricao = Console.ReadLine();
            Console.Write("Preço: ");
            p.Preco = double.Parse(Console.ReadLine());
            Console.Write("Ativo: ");
            p.Ativo = bool.Parse(Console.ReadLine());
            Console.WriteLine(new Produto(p.Codigo, p.Descricao, p.Preco, p.Ativo).ToString());
        }
    }

    class Produto
    {
        private string codigo;
        private string descricao;
        private double preco;
        private bool ativo;

        public Produto()
        {
        }

        public Produto(string codigo, string descricao, double preco, bool ativo)
        {
            Codigo = codigo;
            Descricao = descricao;
            Preco = preco;
            Ativo = ativo;
        }

        public string Codigo 
        { 
            get => codigo; 
            set => codigo = value != "0" ? value : null; 
        }
        public string Descricao 
        { 
            get => descricao; 
            set => descricao = value; 
        }
        public double Preco 
        { 
            get => preco; 
            set => preco = value > 0 ? value : 0; 
        }
        public bool Ativo 
        { 
            get => ativo; 
            set => ativo = value; 
        }

        public override string ToString()
        {
            return "Codigo: " + Codigo + ", Descricao: " + Descricao + ", Preco: " + Preco + ", Ativo: " + Ativo;
        }

    }

}