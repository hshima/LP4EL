﻿using System;
//Aula2_HenriqueShimada

namespace Exercicio1
{
    class Inicio
    {
        static void Main(string[] args)
        {
            Produto p = new Produto();
            Console.Write("Código: ");
            p.SetCodigo(Console.ReadLine());
            Console.Write("Descrição: ");
            p.SetDescricao(Console.ReadLine());
            Console.Write("Preço: ");
            p.SetPreco(double.Parse(Console.ReadLine()));
            Console.Write("Ativo: ");
            p.SetAtivo(bool.Parse(Console.ReadLine()));
            Console.WriteLine(p.ToString());
        }
    }

    class Produto
    {
        private string codigo;
        private string descricao;
        private double preco;
        private bool ativo;

        public string GetCodigo()
        {
            return codigo;
        }

        public void SetCodigo(string codigo)
        {
            this.codigo = codigo;
        }
        public string GetDescricao()
        {
            return descricao;
        }

        public void SetDescricao(string descricao)
        {
            this.descricao = descricao;
        }
        public double GetPreco()
        {
            return preco;
        }

        public void SetPreco(double preco)
        {
            this.preco = preco;
        }
        public bool GetAtivo()
        {
            return ativo;
        }

        public void SetAtivo(bool ativo)
        {
            this.ativo = ativo;
        }
        public override string ToString()
        {
            return "Codigo: " + codigo + ", Descricao: " + descricao + ", Preco: " + preco + ", Ativo: " + ativo;
        }

    }

}