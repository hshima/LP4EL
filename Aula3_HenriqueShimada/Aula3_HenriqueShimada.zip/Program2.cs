﻿using System;
//Aula2_HenriqueShimada

namespace Exercicio2
{
    class Inicio
    {
        static void Main(string[] args)
        {
            Produto p = new Produto();
            Console.Write("Código: ");
            p.Codigo = Console.ReadLine();
            Console.Write("Descrição: ");
            p.Descricao = Console.ReadLine();
            Console.Write("Preço: ");
            p.Preco = double.Parse(Console.ReadLine());
            Console.Write("Ativo: ");
            p.Ativo = bool.Parse(Console.ReadLine());
            Console.WriteLine(p.ToString());
        }
    }

    class Produto
    {
        private string codigo;
        private string descricao;
        private double preco;
        private bool ativo;

        public string Codigo { get => codigo; set => codigo = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public double Preco { get => preco; set => preco = value; }
        public bool Ativo { get => ativo; set => ativo = value; }

        public override string ToString()
        {
            return "Codigo: " + Codigo + ", Descricao: " + Descricao + ", Preco: " + Preco + ", Ativo: " + Ativo;
        }

    }

}