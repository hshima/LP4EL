﻿using System;
using System.Reflection;
using System.Text;

namespace Aula4_HenriqueShimada
{
    class Exercicio02
    {
        public static void Main(string[] args)
        {
            string cor;
            while (true)
            {
                Console.Write(
                    "Informe uma opção para ser calculada:\n" +
                    "0) Sair\n" +
                    "1) Retângulo\n" +
                    "2) Círculo\n" +
                    "Opção: "
                );
                int opt = 0;
                try
                {
                    opt = int.Parse(Console.ReadLine());
                }
                catch (FormatException)
                {
                    opt = 9;
                }

                switch (opt)
                {
                    case 0:
                        return;
                    case 1:
                        Console.Write("Informe a base: ");
                        var b = double.Parse(Console.ReadLine());
                        Console.Write("Informe a altura: ");
                        var h = double.Parse(Console.ReadLine());
                        Console.Write("Informe a cor: ");
                        cor = Console.ReadLine();
                        Console.WriteLine(new Retangulo(b, h, cor).ToString());
                        break;
                    case 2:
                        Console.Write("Informe o raio: ");
                        var r = double.Parse(Console.ReadLine());
                        Console.Write("Informe a cor: ");
                        cor = Console.ReadLine();
                        Console.WriteLine(new Circulo(r, cor).ToString());
                        break;
                    default:
                        Console.WriteLine("Opção inválida, escolha uma das opções numérica. Pressione qualquer tecla para continuar.");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                }
            }

        }
        private abstract class Forma
        {
            private string cor;
            private double area;

            public void ConfigurarCor(string cor)
            {
                this.Cor = cor;
            }

            public abstract double CalculaArea();

            private PropertyInfo[] _PropertyInfos = null;

            public double Area { get => area; set => area = value; }
            public string Cor { get => cor; set => cor = value; }

            public override string ToString()
            {
                if (_PropertyInfos == null)
                    _PropertyInfos = this.GetType().GetProperties();

                var sb = new StringBuilder();
                sb.Append(this.GetType().Name + " [");
                foreach (var info in _PropertyInfos)
                {
                    var value = info.GetValue(this, null) ?? "(null)";
                    if (_PropertyInfos[_PropertyInfos.Length-1] != info)
                        sb.Append(info.Name + ": " + value.ToString() + ", ");
                    else
                        sb.Append(info.Name + ": " + value.ToString() + "]");
                }

                return sb.ToString();
            }
        }

        class Retangulo : Forma
        {
            private double b, h;

            public Retangulo(double b, double h, string cor)
            {
                this.B = b;
                this.H = h;
                base.ConfigurarCor(cor);
                base.Area = CalculaArea();
            }

            public double B { get => b; set => b = value; }
            public double H { get => h; set => h = value; }

            public sealed override double CalculaArea()
            {
                return B * H;
            }
            public override string ToString()
            {
                return base.ToString();
            }
        }

        class Circulo : Forma
        {
            private double r;
            public Circulo(double r, string cor)
            {
                this.R = r;
                base.ConfigurarCor(cor);
                base.Area = this.CalculaArea();
            }

            public double R { get => r; set => r = value; }

            public sealed override double CalculaArea()
            {
                return Math.Pow(R * Math.PI, 2.0);
            }
            public override string ToString()
            {
                return base.ToString();
            }
        }
    }
}
